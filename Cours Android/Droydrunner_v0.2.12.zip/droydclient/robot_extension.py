__author__ = 'cocoon'
"""
    robot_framework droyd extension plugin


"""


from player.scan_hierarchy import RilServiceMod


class DroydExtension(object):
    """




    """

    @classmethod
    def ril_service_mode(cls,dump):
        """


        :param dump: xml string
        :return:
        """

        data= RilServiceMod.from_xml_string(dump).data
        return data


