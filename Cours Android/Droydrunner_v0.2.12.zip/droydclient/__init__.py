__author__ = 'cocoon'

"""

    droyd client is a pseudo package suppling an http client to droyhub


    build :
        copy following file from droydhub package:
            __init__.py
            gateway.py
            http.py
            interface.py
            robot_plugin.py






"""
from droydclient.robot_plugin import Pilot as Droyd