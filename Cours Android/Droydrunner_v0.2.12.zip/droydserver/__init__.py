# -*- coding: utf-8 -*-
"""



    a Mobile interface definition

        adapted from robotframework-uiautomatorlibrary



"""

