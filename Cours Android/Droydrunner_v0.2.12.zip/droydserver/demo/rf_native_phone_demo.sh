#!/bin/sh
export RF_HUB_URL=
pybot -L trace -P ../ -P ../../  rf_phone_demo.robot

