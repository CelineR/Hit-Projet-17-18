#!/bin/sh
export RF_HUB_URL=http://127.0.0.1:5000
#export RF_HUB_URL=
pybot -i base -L trace -P ../ -P ../.. rf_phone_demo.robot


