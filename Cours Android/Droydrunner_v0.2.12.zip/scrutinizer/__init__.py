__author__ = 'cocoon'
"""

    tools to handle  xml dumpo from android screens


    Scrutinizer(xml):
        iter ( root , check , filter )



"""

from core import Scrutinizer , UiNode
